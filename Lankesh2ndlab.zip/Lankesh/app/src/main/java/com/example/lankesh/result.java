package com.example.lankesh;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView res= findViewById(R.id.result2);
        Intent i1 =getIntent();
        Bundle b1=i1.getExtras();
        String sum=b1.getString("sum");
        res.setText("sum: "+sum);
    }
}