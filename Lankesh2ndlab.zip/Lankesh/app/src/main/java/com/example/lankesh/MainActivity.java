package com.example.lankesh;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText Num1=findViewById(R.id.num1);
        EditText Num2=findViewById(R.id.num2);
        Button adder =findViewById(R.id.button);
//        TextView result =findViewById(R.id.result);

        adder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double n1= Double.parseDouble(Num1.getText().toString());
                Double n2=Double.parseDouble(Num2.getText().toString());

                Double sum =n1+n2;
//                result.setText("sum:" +Double.toString(sum));


                Intent i1=new Intent(getApplicationContext(),result.class);
                i1.putExtra("sum",sum.toString());
                startActivity(i1);
            }
        });


    }
}